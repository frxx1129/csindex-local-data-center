@echo off
setlocal
pushd "%~dp0"
for %%F in (*.exe) do (
  "%%~fF" --root .
  popd
  exit /b 0
)
popd
echo No application EXE found in this folder.
pause
